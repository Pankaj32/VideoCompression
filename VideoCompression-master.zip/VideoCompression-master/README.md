# VideoCompression
 VideoCompression
Compressing 25Mb videofile to 1Mb
